#Donut Theme#

Place this folder under qa-theme directory of your q2a installation path 
