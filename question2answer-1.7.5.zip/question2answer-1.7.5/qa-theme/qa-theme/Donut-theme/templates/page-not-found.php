<div class="row page-not-found">
    <div class="text-center">
        <div class="col-xs-12">
            <div class="icon-wrap text-muted">
                <span class="fa fa-unlink large-icon"></span>
            </div>
        </div>
        <div class="col-xs-12">
            <div class="not-found-text text-muted">
                <?php echo qa_opt( 'donut_custom_404_text' ) ?>
            </div>
        </div>
    </div>
</div>
