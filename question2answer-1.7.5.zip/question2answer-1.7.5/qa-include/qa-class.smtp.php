<?php
/**
 * @deprecated This file is deprecated; please use Q2A built-in functions for sending emails.
 */

require_once 'vendor/PHPMailer/PHPMailerAutoload.php';
